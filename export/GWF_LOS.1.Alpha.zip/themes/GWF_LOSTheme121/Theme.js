{
	"wm.AppRoot": {
	}, 
	"wm.TabLayers": {
		"margin": "0", 
		"headerWidth": "50px"
	}, 
	"wm.AccordionLayers": {
	}, 
	"wm.FancyPanel": {
		"innerBorder": "1"
	}, 
	"wm.Button": {
	}, 
	"wm.ToggleButton": {
	}, 
	"wm.PopupMenuButton": {
	}, 
	"wm.ToggleButtonPanel": {
	}, 
	"wm.Text": {
		"captionSize": "120px"
	}, 
	"wm.LargeTextArea": {
	}, 
	"wm.Number": {
	}, 
	"wm.Currency": {
	}, 
	"wm.SelectMenu": {
	}, 
	"wm.Lookup": {
	}, 
	"wm.FilteringLookup": {
	}, 
	"wm.Checkbox": {
	}, 
	"wm.RadioButton": {
	}, 
	"wm.RichText": {
	}, 
	"wm.CheckboxSet": {
	}, 
	"wm.RadioSet": {
	}, 
	"wm.ListSet": {
	}, 
	"wm.Slider": {
	}, 
	"wm.Date": {
	}, 
	"wm.Time": {
	}, 
	"wm.DateTime": {
	}, 
	"wm.DojoGrid": {
		"border": "1,1,1,1"
	}, 
	"wm.List": {
		"border": "1,1,1,1"
	}, 
	"wm.dijit.ProgressBar": {
	}, 
	"wm.Bevel": {
	}, 
	"wm.Splitter": {
	}, 
	"wm.dijit.Calendar": {
		"border": "1,1,1,1", 
		"desktopHeight": "180px", 
		"borderColor": "#410f0f"
	}, 
	"wm.Dialog": {
	}, 
	"wm.PageDialog": {
	}, 
	"wm.GenericDialog": {
	}, 
	"wm.DesignableDialog": {
	}, 
	"wm.ButtonBarPanel": {
	}, 
	"wm.DojoMenu": {
		"borderColor": "#ffffff"
	}, 
	"wm.Toast": {
	}
}