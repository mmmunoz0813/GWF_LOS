
package com.dbgwfloansdb.data;



/**
 *  dbgwfloansDB.Tbcodename
 *  04/23/2015 17:35:12
 * 
 */
public class Tbcodename {

    private String codename;

    public String getCodename() {
        return codename;
    }

    public void setCodename(String codename) {
        this.codename = codename;
    }

}
