
package com.dbgwfloansdb.data;



/**
 *  dbgwfloansDB.Tbdocuments
 *  04/23/2015 17:35:12
 * 
 */
public class Tbdocuments {

    private Integer docId;
    private String document;
    private String remarks;

    public Integer getDocId() {
        return docId;
    }

    public void setDocId(Integer docId) {
        this.docId = docId;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

}
