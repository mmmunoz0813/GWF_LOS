
package com.dbgwfloansdb;



/**
 *  Query names for service "dbgwfloansDB"
 *  04/24/2015 08:00:45
 * 
 */
public class DbgwfloansDBConstants {

    public final static String getTbcodenameByIdQueryName = "getTbcodenameById";

}
