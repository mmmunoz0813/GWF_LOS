
package com.dbgwfloansdb.data;



/**
 *  dbgwfloansDB.Tbbranch
 *  04/23/2015 17:35:12
 * 
 */
public class Tbbranch {

    private String brcode;
    private String brname;
    private String braddress;
    private String brtype;
    private String brstatus;

    public String getBrcode() {
        return brcode;
    }

    public void setBrcode(String brcode) {
        this.brcode = brcode;
    }

    public String getBrname() {
        return brname;
    }

    public void setBrname(String brname) {
        this.brname = brname;
    }

    public String getBraddress() {
        return braddress;
    }

    public void setBraddress(String braddress) {
        this.braddress = braddress;
    }

    public String getBrtype() {
        return brtype;
    }

    public void setBrtype(String brtype) {
        this.brtype = brtype;
    }

    public String getBrstatus() {
        return brstatus;
    }

    public void setBrstatus(String brstatus) {
        this.brstatus = brstatus;
    }

}
