
package com.dbgwfloansdb.data;



/**
 *  dbgwfloansDB.Tbcodes
 *  04/23/2015 17:35:12
 * 
 */
public class Tbcodes {

    private Integer codeId;
    private String codename;
    private String codevalue;
    private String codedesc1;
    private String codedesc2;
    private String remarks;

    public Integer getCodeId() {
        return codeId;
    }

    public void setCodeId(Integer codeId) {
        this.codeId = codeId;
    }

    public String getCodename() {
        return codename;
    }

    public void setCodename(String codename) {
        this.codename = codename;
    }

    public String getCodevalue() {
        return codevalue;
    }

    public void setCodevalue(String codevalue) {
        this.codevalue = codevalue;
    }

    public String getCodedesc1() {
        return codedesc1;
    }

    public void setCodedesc1(String codedesc1) {
        this.codedesc1 = codedesc1;
    }

    public String getCodedesc2() {
        return codedesc2;
    }

    public void setCodedesc2(String codedesc2) {
        this.codedesc2 = codedesc2;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

}
