
package com.dbgwfloansdb.data;



/**
 *  dbgwfloansDB.Tbrole
 *  04/23/2015 17:35:12
 * 
 */
public class Tbrole {

    private Integer roleId;
    private String rolename;
    private String roledesc;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    public String getRoledesc() {
        return roledesc;
    }

    public void setRoledesc(String roledesc) {
        this.roledesc = roledesc;
    }

}
