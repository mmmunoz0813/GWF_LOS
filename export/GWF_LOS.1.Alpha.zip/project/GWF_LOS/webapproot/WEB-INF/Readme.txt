  web.xml is a studio managed file. Use user-web.xml. Changes to user-web.xml will be merged into web.xml for deployment.
