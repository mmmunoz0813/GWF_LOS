dojo.declare("LoanProductSetup", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

LoanProductSetup.widgets = {
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
panel3: ["wm.Panel", {"border":"1","height":"551px","horizontalAlign":"left","margin":"10","padding":"5","styles":{},"verticalAlign":"top","width":"100%"}, {}, {
panel1: ["wm.Panel", {"border":"0,0,2,0","height":"48px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"5,5,5,10","styles":{},"verticalAlign":"middle","width":"100%"}, {}, {
label1: ["wm.Label", {"_classes":{"domNode":["PageTitle"]},"caption":"Loan Product Setup","height":"30px","padding":"4","styles":{}}, {}]
}],
panel5: ["wm.Panel", {"height":"215px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"10,5,5,5","styles":{},"verticalAlign":"top","width":"100%"}, {}, {
panel6: ["wm.Panel", {"_classes":{"domNode":["panel1"]},"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
text1: ["wm.Text", {"_classes":{"domNode":["GWF1"]},"caption":"Product Code:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px","required":true,"styles":{}}, {}],
text2: ["wm.Text", {"_classes":{"domNode":["GWF1"]},"caption":"Product Name:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px","required":true,"width":"362px"}, {}],
number1: ["wm.Number", {"_classes":{"domNode":["GWF1"]},"applyPlacesWhileTyping":true,"border":"0","caption":"Min Interest Rate:","captionSize":"150px","dataValue":undefined,"displayValue":"","height":"30px","minimum":0,"places":2}, {}],
number2: ["wm.Number", {"_classes":{"domNode":["GWF1"]},"applyPlacesWhileTyping":true,"border":"0","caption":"Max Interest Rate:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px","minimum":0,"places":2}, {}],
number3: ["wm.Number", {"_classes":{"domNode":["GWF1"]},"applyPlacesWhileTyping":true,"border":"0","caption":"Min Loanable Amount:","captionSize":"150px","dataValue":undefined,"displayValue":"","height":"30px","minimum":0,"places":2}, {}],
number4: ["wm.Number", {"_classes":{"domNode":["GWF1"]},"applyPlacesWhileTyping":true,"border":"0","caption":"Max Loanable Amount:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px","minimum":0,"places":2}, {}]
}],
panel7: ["wm.Panel", {"_classes":{"domNode":["panel1"]},"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
selectMenu1: ["wm.SelectMenu", {"_classes":{"domNode":["GWF1"]},"caption":"Product Type:","captionSize":"150px","dataValue":undefined,"displayValue":"","height":"30px"}, {}],
number5: ["wm.Number", {"_classes":{"domNode":["GWF1"]},"border":"0","caption":"Minimum DP Required:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px"}, {}],
checkbox1: ["wm.Checkbox", {"_classes":{"domNode":["GWF1"]},"caption":"Co-maker Required?","captionSize":"150px","dataValue":false,"displayValue":false,"height":"30px"}, {}],
selectMenu2: ["wm.SelectMenu", {"_classes":{"domNode":["GWF1"]},"caption":"Interest Base Year:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px"}, {}],
selectMenu3: ["wm.SelectMenu", {"_classes":{"domNode":["GWF1"]},"caption":"Product Group:","captionSize":"150px","dataValue":undefined,"desktopHeight":"30px","displayValue":"","height":"30px"}, {}]
}]
}],
panel4: ["wm.Panel", {"height":"54px","horizontalAlign":"right","layoutKind":"left-to-right","margin":"5","padding":"5,5,5,5","styles":{},"verticalAlign":"top","width":"100%"}, {}, {
btnNewCode: ["wm.Button", {"_classes":{"domNode":["GWF1Button"]},"border":"1","caption":"New Code","hint":"Clear Fields","margin":"4","styles":{}}, {"onclick":"btnNewCodeClick"}],
btnSaveCode: ["wm.Button", {"_classes":{"domNode":["GWF1Button"]},"border":"1","caption":"Submit","hint":"Save Code","margin":"4"}, {"onclick":"svSaveCode"}]
}],
panel2: ["wm.Panel", {"height":"202px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
dojoGrid1: ["wm.DojoGrid", {"_classes":{"domNode":["GWF1Grid"]},"columns":[
{"show":true,"field":"codeId","title":"CodeId","width":"80px","displayType":"Number","align":"right","formatFunc":""},
{"show":true,"field":"codename","title":"Codename","width":"100%","displayType":"Text","align":"left","formatFunc":""},
{"show":true,"field":"codevalue","title":"Codevalue","width":"100%","displayType":"Text","align":"left","formatFunc":""},
{"show":true,"field":"codedesc1","title":"Codedesc1","width":"100%","displayType":"Text","align":"left","formatFunc":""},
{"show":true,"field":"codedesc2","title":"Codedesc2","width":"100%","displayType":"Text","align":"left","formatFunc":""},
{"show":true,"field":"remarks","title":"Remarks","width":"100%","displayType":"Text","align":"left","formatFunc":""},
{"show":false,"field":"PHONE COLUMN","title":"-","width":"100%","align":"left","expression":"\"<div class='MobileRowTitle'>\" +\n\"CodeId: \" + ${codeId} +\n\"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Codename: \" + ${codename}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Codevalue: \" + ${codevalue}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Codedesc1: \" + ${codedesc1}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Codedesc2: \" + ${codedesc2}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Remarks: \" + ${remarks}\n + \"</div>\"\n\n","mobileColumn":true}
],"margin":"4","minDesktopHeight":60,"singleClickEdit":true}, {"onCellDblClick":"dojoGrid1CellDblClick"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"svCodesList","targetProperty":"dataSet"}, {}]
}]
}]
}]
}]
}]
};

LoanProductSetup.prototype._cssText = '';
LoanProductSetup.prototype._htmlText = '';