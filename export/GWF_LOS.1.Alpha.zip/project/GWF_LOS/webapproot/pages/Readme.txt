You can edit your pages here; be warned that if you edit a page that you have open in studio's designer, that changes you made in the designer will be lost
