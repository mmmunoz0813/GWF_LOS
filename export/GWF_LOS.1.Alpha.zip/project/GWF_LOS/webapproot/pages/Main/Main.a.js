dojo.declare("Main", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

Main.widgets = {
navBranchSetup: ["wm.NavigationCall", {"operation":"gotoPageContainerPage"}, {}, {
input: ["wm.ServiceInput", {"type":"gotoPageContainerPageInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"BranchSetup\"","targetProperty":"pageName"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"pageContainer1","targetProperty":"pageContainer"}, {}]
}]
}]
}],
navCodesSetup: ["wm.NavigationCall", {"operation":"gotoPageContainerPage"}, {}, {
input: ["wm.ServiceInput", {"type":"gotoPageContainerPageInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"CodeSetup\"","targetProperty":"pageName"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"pageContainer1","targetProperty":"pageContainer"}, {}]
}]
}]
}],
navUserRole: ["wm.NavigationCall", {"operation":"gotoPageContainerPage"}, {}, {
input: ["wm.ServiceInput", {"type":"gotoPageContainerPageInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"RoleSetup\"","targetProperty":"pageName"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"pageContainer1","targetProperty":"pageContainer"}, {}]
}]
}]
}],
navUserSetup: ["wm.NavigationCall", {"operation":"gotoPageContainerPage"}, {}, {
input: ["wm.ServiceInput", {"type":"gotoPageContainerPageInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire1: ["wm.Wire", {"expression":undefined,"source":"pageContainer1","targetProperty":"pageContainer"}, {}],
wire: ["wm.Wire", {"expression":"\"UserList\"","targetProperty":"pageName"}, {}]
}]
}]
}],
navDocumentsRequirements: ["wm.NavigationCall", {"operation":"gotoPageContainerPage"}, {}, {
input: ["wm.ServiceInput", {"type":"gotoPageContainerPageInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"DocumentRequirementsSetup\"","targetProperty":"pageName"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"pageContainer1","targetProperty":"pageContainer"}, {}]
}]
}]
}],
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","styles":{},"verticalAlign":"top"}, {}, {
TitleBar: ["wm.Panel", {"_classes":{"domNode":["titlebar"]},"border":"0,0,4,0","height":"77px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"8","styles":{"backgroundColor":"#521818"},"verticalAlign":"top","width":"100%"}, {}, {
picture1: ["wm.Picture", {"aspect":"h","deviceType":null,"height":"60px","imageIndex":0,"imageList":undefined,"source":"resources/images/logos/GWF/globewest_logo.png","styles":{},"width":"81px"}, {}],
appNameLabel: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_24px"]},"caption":"Loan Origination System","height":"62px","margin":"0,0,0,10","padding":"4","styles":{"color":"#ffffff","fontWeight":"bold","fontStyle":"normal","fontFamily":"arial"},"width":"100%"}, {}],
panel3: ["wm.Panel", {"border":"1","height":"100%","styles":{},"width":"222px"}, {}]
}],
panel1: ["wm.Panel", {"height":"37px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
dojoMenu1: ["wm.DojoMenu", {"fullStructure":[
{"label":"Home","separator":undefined,"defaultLabel":"Home","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Inquiry","separator":undefined,"defaultLabel":"Inquiry","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[
{"label":"Loan Application","separator":undefined,"defaultLabel":"Loan Application","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Negative File","separator":undefined,"defaultLabel":"Negative File","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Customer Information","separator":undefined,"defaultLabel":"Customer Information","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}
]},
{"label":"Loan Application","separator":undefined,"defaultLabel":"Loan Application","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[
{"label":"New Application","separator":undefined,"defaultLabel":"New Application","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Loan Kiosk Data","separator":undefined,"defaultLabel":"Loan Kiosk Data","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Encoding","separator":undefined,"defaultLabel":"Encoding","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Pre-screening","separator":undefined,"defaultLabel":"Pre-screening","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Credit Investigation","separator":undefined,"defaultLabel":"Credit Investigation","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[
{"label":"CI Assignment","separator":undefined,"defaultLabel":"CI Assignment","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"For CI","separator":undefined,"defaultLabel":"For CI","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"CI Report","separator":undefined,"defaultLabel":"CI Report","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}
]},
{"label":"Credit Evaluation","separator":undefined,"defaultLabel":"Credit Evaluation","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Credit Approval","separator":undefined,"defaultLabel":"Credit Approval","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Client Acceptance","separator":undefined,"defaultLabel":"Client Acceptance","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Release / Booking","separator":undefined,"defaultLabel":"Release / Booking","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Document Printing","separator":undefined,"defaultLabel":"Document Printing","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}
]},
{"label":"Other Transactions","separator":undefined,"defaultLabel":"Other Transactions","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[
{"label":"Emergency Loan","separator":undefined,"defaultLabel":"Emergency Loan","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Cash Advance","separator":undefined,"defaultLabel":"Cash Advance","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Loan Restructuring","separator":undefined,"defaultLabel":"Loan Restructuring","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Loan Amendment","separator":undefined,"defaultLabel":"Loan Amendment","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}
]},
{"label":"Reports","separator":undefined,"defaultLabel":"Reports","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"System Admin","separator":undefined,"defaultLabel":"System Admin","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[
{"label":"Branch","separator":undefined,"defaultLabel":"Branch","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"navBranchSetup","children":[]},
{"label":"Loan Product","separator":undefined,"defaultLabel":"Loan Product","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"User Account","separator":undefined,"defaultLabel":"User Account","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"navUserSetup","children":[]},
{"label":"User Role","separator":undefined,"defaultLabel":"User Role","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"navUserRole","children":[]},
{"label":"Audit Trail","separator":undefined,"defaultLabel":"Audit Trail","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Parameters","separator":undefined,"defaultLabel":"Parameters","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"navCodesSetup","children":[]},
{"label":"Documentary Requirements","separator":undefined,"defaultLabel":"Documentary Requirements","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"navDocumentsRequirements","children":[]},
{"label":"Drawers","separator":undefined,"defaultLabel":"Drawers","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},
{"label":"Drawers Class","separator":undefined,"defaultLabel":"Drawers Class","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}
]}
],"localizationStructure":{},"padding":"4","styles":{}}, {}]
}],
panel2: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pageContainer1: ["wm.PageContainer", {"deferLoad":true,"pageName":"Home","styles":{},"subpageEventlist":{},"subpageMethodlist":{},"subpageProplist":{}}, {}]
}],
Footer: ["wm.Panel", {"_classes":{"domNode":["toolbar"]},"height":"36px","horizontalAlign":"center","padding":"2","verticalAlign":"middle","width":"100%"}, {}, {
footerLabel: ["wm.Label", {"align":"center","caption":"Copyright 2012 Eteligent","height":"100%","padding":"4","width":"100%"}, {}]
}]
}]
};

Main.prototype._cssText = '';
Main.prototype._htmlText = '';