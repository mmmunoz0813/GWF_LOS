package com.los.common.util;

//--- UTILITIES
import java.util.HashMap;
import java.util.Map;


/**
*  eteligent software solutions, inc.
*/
public class HQLUtil
{
    /**
     * Returns map for storing hql parameters
     * @return Map
     */
    public static Map<String, Object> getMap()
    {
        Map<String, Object> map = new HashMap<String, Object>();
        return map;
    }
}
