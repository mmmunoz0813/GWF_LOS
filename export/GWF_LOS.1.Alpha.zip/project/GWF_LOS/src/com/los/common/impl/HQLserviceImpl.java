package com.los.common.impl;

import java.util.Map;

import org.apache.log4j.Logger;

import com.los.common.service.HQLservice;



public class HQLserviceImpl implements HQLservice {

	private static final Logger logger = Logger.getLogger(HQLserviceImpl.class);

	
}
