package com.los.common.service;



public interface HQLservice {

	

}
